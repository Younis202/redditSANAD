import { motion } from "motion/react";

export default function App() {
  return (
    <div className="min-h-screen">
      {/* Premium Top Navigation */}
      <header className="fixed top-0 w-full z-50 h-20 flex items-center px-8 glass-card border-b-0">
        <nav className="flex justify-between items-center w-full max-w-[1800px] mx-auto">
          <div className="flex items-center gap-12">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white">
                <span className="material-symbols-outlined font-bold">analytics</span>
              </div>
              <span className="text-2xl font-extrabold tracking-tight font-headline">
                SANAD <span className="font-light text-slate-400">HQ</span>
              </span>
            </div>
            <div className="hidden lg:flex gap-8">
              <a className="text-primary font-bold transition-all relative after:content-[''] after:absolute after:-bottom-2 after:left-0 after:w-full after:h-0.5 after:bg-primary" href="#">Command</a>
              <a className="text-slate-500 font-medium hover:text-primary transition-all" href="#">Emergency</a>
              <a className="text-slate-500 font-medium hover:text-primary transition-all" href="#">Policy</a>
              <a className="text-slate-500 font-medium hover:text-primary transition-all" href="#">Cybersecurity</a>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center bg-black/5 px-5 py-2.5 rounded-full gap-3 focus-within:ring-2 focus-within:ring-primary/20 transition-all">
              <span className="material-symbols-outlined text-slate-400 text-lg">search</span>
              <input className="bg-transparent border-none focus:ring-0 text-sm w-64 placeholder:text-slate-400 font-medium" placeholder="Analyze national entities..." type="text" />
            </div>
            <div className="flex items-center gap-3">
              <button className="p-2.5 text-slate-500 hover:bg-black/5 rounded-full transition-all relative">
                <span className="material-symbols-outlined">notifications</span>
                <span className="absolute top-2 right-2 w-2 h-2 bg-error rounded-full border-2 border-white"></span>
              </button>
              <div className="h-8 w-px bg-slate-200 mx-1"></div>
              <div className="flex items-center gap-3 hover:bg-black/5 p-1 pr-4 rounded-full cursor-pointer transition-all">
                <img alt="Director" className="w-9 h-9 rounded-full object-cover shadow-sm" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCJODpdldjgrrr9Q_lrT94Lu3uaIrjYlzSDgcPgr-J1HU_tpX8sFiHPD7OF852G47zsGKv7NB7QWCCtlCkCq-Ah-yKsWflJ9uM9Hvab_pnn7Jo-mK7UpwooAnjcVeFxUJpx3mEI9SnPKA5ZyA5soOY8xmd03xNSo3dS3EQHZGLhj--AzW5Iu78pw1uHZykZAtF430HUXeQ901uXoc4KQMS8e2Mt8seooRKzJVgVQVnZeDFGngfSkPpimX8hRwsbeK9FTJC6rNsCqoZU" referrerPolicy="no-referrer" />
                <div className="flex flex-col">
                  <span className="text-xs font-bold leading-none">Command Director</span>
                  <span className="text-[10px] text-slate-400 font-medium">National Ops</span>
                </div>
              </div>
            </div>
          </div>
        </nav>
      </header>

      <main className="pt-28 pb-20 px-8 max-w-[1800px] mx-auto space-y-10">
        {/* Header Info */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6"
        >
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 bg-primary/10 text-primary text-[10px] font-bold rounded-full uppercase tracking-wider">Strategic Level 1</span>
              <span className="text-slate-400 text-xs font-medium">Last sync: 2 min ago</span>
            </div>
            <h1 className="text-5xl font-extrabold font-headline tracking-tight">National Health Intelligence</h1>
            <p className="text-slate-500 mt-2 font-medium">Integrated real-time oversight of the Kingdom's clinical infrastructure and population health.</p>
          </div>
          <div className="flex gap-4">
            <button className="flex items-center gap-2 px-6 py-3 glass-card rounded-2xl font-bold text-sm hover:bg-white transition-all shadow-sm">
              <span className="material-symbols-outlined text-[20px]">calendar_today</span>
              <span>Q2 2025 Reports</span>
            </button>
            <button className="flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-2xl font-bold text-sm hover:opacity-90 shadow-lg shadow-primary/20 transition-all">
              <span className="material-symbols-outlined text-[20px]">ios_share</span>
              <span>Cabinet Export</span>
            </button>
          </div>
        </motion.div>

        {/* 1. National KPI Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <KPICard icon="groups" label="Registered Patients" value="14,284,502" trend="+2.4%" color="primary" />
          <KPICard icon="medical_services" label="Visits Today" value="84,921" trend="+12.8%" color="secondary" />
          <KPICard icon="security" label="Blocked AI Interactions" value="1,042" subLabel="Critical Saved" color="error" />
          <KPICard icon="hub" label="Connected Hospitals" value="482" isLive color="tertiary" />
        </div>

        {/* Middle Grid: Trends & AI Cluster */}
        <div className="grid grid-cols-12 gap-8">
          {/* National Visit Trends */}
          <div className="col-span-12 lg:col-span-8 glass-card p-8 rounded-[2.5rem]">
            <div className="flex justify-between items-center mb-10">
              <div>
                <h3 className="text-xl font-bold font-headline">National Visit Trends</h3>
                <p className="text-slate-400 text-xs font-medium">Real-time load balancing across all regions</p>
              </div>
              <div className="flex gap-6">
                <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-primary"></span> <span className="text-xs font-bold text-slate-500 uppercase">Total Visits</span></div>
                <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full border-2 border-error bg-transparent"></span> <span className="text-xs font-bold text-slate-500 uppercase">Emergency</span></div>
              </div>
            </div>
            <div className="h-[300px] w-full relative group">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 800 240">
                <line stroke="rgba(0,0,0,0.05)" strokeWidth="1" x1="0" x2="800" y1="0" y2="0"></line>
                <line stroke="rgba(0,0,0,0.05)" strokeWidth="1" x1="0" x2="800" y1="80" y2="80"></line>
                <line stroke="rgba(0,0,0,0.05)" strokeWidth="1" x1="0" x2="800" y1="160" y2="160"></line>
                <line stroke="rgba(0,0,0,0.1)" strokeWidth="1" x1="0" x2="800" y1="240" y2="240"></line>
                <path d="M0,180 Q100,140 200,160 T400,80 T600,120 T800,40 V240 H0 Z" fill="url(#blue-grad)" opacity="0.1"></path>
                <defs>
                  <linearGradient id="blue-grad" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="#007AFF"></stop>
                    <stop offset="100%" stopColor="#007AFF" stopOpacity="0"></stop>
                  </linearGradient>
                </defs>
                <path d="M0,180 Q100,140 200,160 T400,80 T600,120 T800,40" fill="none" stroke="#007AFF" strokeLinecap="round" strokeWidth="4"></path>
                <path d="M0,220 Q100,210 200,215 T400,190 T600,200 T800,170" fill="none" stroke="#FF3B30" strokeDasharray="8 6" strokeWidth="3"></path>
                <circle className="drop-shadow-lg" cx="400" cy="80" fill="#007AFF" r="6" stroke="white" strokeWidth="3"></circle>
              </svg>
              <div className="flex justify-between mt-6 px-2">
                {["JAN", "FEB", "MAR", "APR (CUR)", "MAY", "JUN", "JUL"].map((month, i) => (
                  <span key={month} className={`text-[10px] font-bold ${i === 3 ? 'text-primary' : 'text-slate-400'}`}>{month}</span>
                ))}
              </div>
            </div>
          </div>

          {/* AI Engine Cluster */}
          <div className="col-span-12 lg:col-span-4 flex flex-col gap-8">
            <div className="glass-card-dark p-8 rounded-[2.5rem] flex-1">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-primary/20 rounded-lg">
                  <span className="material-symbols-outlined text-primary text-xl">psychology</span>
                </div>
                <h3 className="text-lg font-bold">National AI Engines</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <AIEngineStat label="Risk Scoring" value="Online" status="secondary" animate />
                <AIEngineStat label="Decision Hub" value="Optimal" status="secondary" />
                <AIEngineStat label="Digital Twin" value="Simulating" status="primary" spin />
                <AIEngineStat label="Behavioral" value="Learning" status="secondary" />
                <AIEngineStat label="Policy Intel" value="94.2% Conf" status="secondary" />
                <AIEngineStat label="Audit Layer" value="Secure" status="secondary" />
              </div>
              <div className="mt-6 pt-6 border-t border-white/10">
                <div className="flex items-center gap-2 text-error mb-3">
                  <span className="material-symbols-outlined text-sm">emergency_home</span>
                  <span className="text-[10px] font-bold uppercase tracking-widest">Epidemic Radar</span>
                </div>
                <div className="bg-error/10 border border-error/20 p-4 rounded-2xl flex gap-3 items-center">
                  <div className="w-2 h-10 bg-error rounded-full"></div>
                  <div>
                    <p className="text-xs font-bold text-white">Flu Spike Detected: Riyadh Central</p>
                    <p className="text-[10px] text-slate-400">Policy engine recommending preparedness level increase.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Disease & Demographics */}
        <div className="grid grid-cols-12 gap-8">
          <div className="col-span-12 lg:col-span-5 glass-card p-8 rounded-[2.5rem]">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-xl font-bold font-headline">Top Chronic Conditions</h3>
              <span className="text-[10px] font-bold text-slate-400 uppercase">National Census 2025</span>
            </div>
            <div className="space-y-6">
              <ConditionProgress label="Hypertension" value="2.4M" progress={85} />
              <ConditionProgress label="Diabetes (Type 2)" value="1.8M" progress={65} />
              <ConditionProgress label="Cardiac Issues" value="940K" progress={45} />
              <ConditionProgress label="Asthma" value="720K" progress={32} />
            </div>
          </div>

          <div className="col-span-12 lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-card p-8 rounded-[2.5rem] flex flex-col items-center">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8 self-start">Risk Distribution</h3>
              <div className="relative w-48 h-48 mb-8">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" fill="transparent" r="40" stroke="#F1F5F9" strokeWidth="12"></circle>
                  <circle cx="50" cy="50" fill="transparent" r="40" stroke="#FF3B30" strokeDasharray="30 251.2" strokeDashoffset="0" strokeWidth="12"></circle>
                  <circle cx="50" cy="50" fill="transparent" r="40" stroke="#FF9500" strokeDasharray="60 251.2" strokeDashoffset="-30" strokeWidth="12"></circle>
                  <circle cx="50" cy="50" fill="transparent" r="40" stroke="#007AFF" strokeDasharray="95 251.2" strokeDashoffset="-90" strokeWidth="12"></circle>
                  <circle cx="50" cy="50" fill="transparent" r="40" stroke="#34C759" strokeDasharray="66.2 251.2" strokeDashoffset="-185" strokeWidth="12"></circle>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-black">AI-Risk</span>
                  <span className="text-[10px] text-slate-400 font-bold">Dynamic</span>
                </div>
              </div>
              <div className="grid grid-cols-2 w-full gap-4">
                <RiskLegend color="error" label="Critical (12%)" />
                <RiskLegend color="warning" label="High (24%)" />
                <RiskLegend color="primary" label="Medium (38%)" />
                <RiskLegend color="secondary" label="Low (26%)" />
              </div>
            </div>

            <div className="glass-card p-8 rounded-[2.5rem]">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8">Age Groups</h3>
              <div className="h-48 flex items-end justify-between gap-3">
                <AgeBar label="0-18" height="40%" />
                <AgeBar label="19-35" height="75%" />
                <AgeBar label="36-55" height="95%" active />
                <AgeBar label="56-70" height="60%" />
                <AgeBar label="70+" height="25%" />
              </div>
            </div>
          </div>
        </div>

        {/* Regional Command Center Grid */}
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-2xl font-black font-headline">Saudi Regional Command Grid</h3>
            <span className="px-3 py-1 bg-white text-slate-400 text-[10px] font-bold rounded-full border border-slate-200">13 Regions Active</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-4">
            <RegionCard name="Riyadh" status="CRITICAL" patients="14.2K" coverage="97%" alert="DIABETES SURGE" color="error" />
            <RegionCard name="Makkah" status="CRITICAL" patients="9.8K" coverage="95%" alert="HTN SPIKE (+12%)" color="error" />
            <RegionCard name="Eastern" status="STABLE" patients="7.6K" coverage="93%" alert="CKD MONITORING" color="primary" />
            <RegionCard name="Madinah" status="OPTIMAL" patients="5.4K" coverage="91%" color="secondary" />
            <RegionCard name="Asir" status="OPTIMAL" patients="3.9K" coverage="84%" color="secondary" />
            <RegionCard name="Qassim" status="STABLE" patients="2.8K" coverage="89%" color="primary" />
            <RegionCard name="Tabuk" status="STABLE" patients="2.1K" coverage="82%" color="primary" />
            <RegionCard name="Hail" status="OPTIMAL" patients="1.6K" coverage="78%" color="secondary" />
            <RegionCard name="Jizan" status="LOW COVERAGE" patients="2.9K" coverage="76%" color="error" />
            <RegionCard name="Najran" status="STABLE" patients="1.4K" coverage="72%" color="primary" />
            <RegionCard name="Al Baha" status="OPTIMAL" patients="900" coverage="71%" color="secondary" />
            <RegionCard name="North Border" status="OPTIMAL" patients="700" coverage="68%" color="secondary" />
            <RegionCard name="Al Jouf" status="OPTIMAL" patients="1.1K" coverage="75%" color="secondary" />
          </div>
        </div>

        {/* Hospital Ranking League Table */}
        <div className="glass-card rounded-[2.5rem] overflow-hidden">
          <div className="p-8 flex justify-between items-center border-b border-black/5">
            <div>
              <h3 className="text-xl font-bold font-headline">National Hospital Performance</h3>
              <p className="text-slate-400 text-xs font-medium">Real-time benchmark scoring for top Tier 1 facilities</p>
            </div>
            <button className="px-5 py-2.5 bg-black text-white text-xs font-bold rounded-xl hover:bg-slate-800 transition-all">View Full League Table</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50/50 text-[10px] uppercase font-bold tracking-widest text-slate-400">
                <tr>
                  <th className="px-8 py-5">Rank</th>
                  <th className="px-8 py-5">Facility Name</th>
                  <th className="px-8 py-5">Region</th>
                  <th className="px-8 py-5">Beds</th>
                  <th className="px-8 py-5">AI Adoption</th>
                  <th className="px-8 py-5">Mortality Rate</th>
                  <th className="px-8 py-5">Composite Score</th>
                  <th className="px-8 py-5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-black/5 font-medium">
                <TableRow rank="01" name="King Faisal Specialist Hospital" region="Riyadh" beds="1,200" adoption="98%" mortality="1.1%" score="96.4" status="Elite" statusColor="secondary" />
                <TableRow rank="02" name="King Fahad Medical City" region="Riyadh" beds="1,700" adoption="96%" mortality="1.3%" score="93.1" status="Optimal" statusColor="secondary" />
                <TableRow rank="03" name="Makkah Al-Mukarramah Hospital" region="Makkah" beds="900" adoption="89%" mortality="1.8%" score="87.5" status="Observe" statusColor="warning" />
              </tbody>
            </table>
          </div>
        </div>

        {/* AI Clinical Impact Tracker */}
        <div className="glass-card p-10 rounded-[3rem] border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
          <div className="flex items-center gap-4 mb-10">
            <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center text-white shadow-xl shadow-primary/30">
              <span className="material-symbols-outlined font-bold">clinical_notes</span>
            </div>
            <div>
              <h3 className="text-2xl font-black font-headline">National AI Clinical Impact Tracker</h3>
              <p className="text-slate-500 font-medium">Real-time valuation of AI assistance in patient outcomes and cost avoidance.</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <ImpactStat label="Lives Directly Impacted" value="2.84M" trend="+14% vs. pre-AI baseline" />
            <ImpactStat label="National SAR Saved" value="4.7B" sub="Directly from AI cost-avoidance logic" />
            <ImpactStat label="Hosp. Prevented" value="73,481" trend="Early intervention success" isCheck />
          </div>
        </div>

        {/* Bottom: Cybersecurity & Policy */}
        <div className="grid grid-cols-12 gap-8">
          <div className="col-span-12 lg:col-span-6 glass-card p-8 rounded-[2.5rem]">
            <div className="flex justify-between items-center mb-8">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-secondary/10 rounded-lg text-secondary">
                  <span className="material-symbols-outlined text-xl">verified_user</span>
                </div>
                <h3 className="text-xl font-bold font-headline">NCA Cybersecurity & PDPL</h3>
              </div>
              <span className="px-3 py-1 bg-secondary text-white text-[10px] font-black rounded-full uppercase tracking-widest">Shield Active</span>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">NCA CSF Score</p>
                <p className="text-2xl font-black">94.2/100</p>
              </div>
              <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">PDPL Compliance</p>
                <p className="text-2xl font-black">97.8%</p>
              </div>
            </div>
            <div className="space-y-4">
              <SecurityItem icon="lock" label="Data Encryption (AES-256)" value="ACTIVE" />
              <SecurityItem icon="fingerprint" label="IAM Audit Coverage" value="99.9%" />
            </div>
          </div>

          <div className="col-span-12 lg:col-span-6 glass-card p-8 rounded-[2.5rem]">
            <div className="flex items-center gap-3 mb-8">
              <div className="p-2 bg-tertiary/10 rounded-lg text-tertiary">
                <span className="material-symbols-outlined text-xl">lightbulb</span>
              </div>
              <h3 className="text-xl font-bold font-headline">Policy Intelligence Recommendations</h3>
            </div>
            <div className="space-y-4">
              <PolicyItem title="Deploy 3 mobile diabetes clinics to Riyadh Northern Districts" desc="Estimating 45K undiagnosed cases via predictive modeling. ROI estimate: SAR 12M/yr." />
              <PolicyItem title="Expand CKD screening in Madinah Region" desc="Integrate eGFR testing in all primary care centers. Targeted at patients 45+." />
              <PolicyItem title="COPD awareness campaign: Southern Highlands" desc="Elevated respiratory burden detected in Jizan and Asir highland zones." />
            </div>
          </div>
        </div>
      </main>

      {/* Contextual Action Bar */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-white/60 backdrop-blur-3xl px-8 py-5 rounded-[2.5rem] shadow-2xl border border-white/20 z-50">
        <NavButton icon="dashboard" label="Overview" />
        <div className="w-px h-10 bg-slate-200"></div>
        <NavButton icon="map" label="Geospatial" />
        <button className="bg-primary text-white w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg shadow-primary/40 hover:scale-105 active:scale-95 transition-all">
          <span className="material-symbols-outlined font-bold text-2xl">add</span>
        </button>
        <NavButton icon="monitoring" label="Live Feed" />
        <div className="w-px h-10 bg-slate-200"></div>
        <NavButton icon="settings" label="System" />
      </div>

      <footer className="pb-32 pt-12 flex flex-col items-center gap-4 text-slate-400 text-[10px] font-black uppercase tracking-[0.3em]">
        <div className="flex items-center gap-8">
          <span>NCA Certified Platform v4.0</span>
          <span>MOH Data Authority</span>
          <span>Tier 4 Mission Critical</span>
        </div>
        <p>© 2025 SANAD National Intelligence Command Center • Kingdom of Saudi Arabia</p>
      </footer>
    </div>
  );
}

function KPICard({ icon, label, value, trend, subLabel, isLive, color }: any) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="glass-card p-7 rounded-[2rem] flex flex-col justify-between min-h-[160px]"
    >
      <div className="flex justify-between items-start">
        <div className={`w-12 h-12 bg-${color}/10 text-${color} rounded-2xl flex items-center justify-center`}>
          <span className="material-symbols-outlined text-2xl font-bold">{icon}</span>
        </div>
        {trend && (
          <span className="px-2.5 py-1 bg-secondary/10 text-secondary text-xs font-bold rounded-full flex items-center gap-1">
            {trend} <span className="material-symbols-outlined text-sm">trending_up</span>
          </span>
        )}
        {subLabel && <span className="text-slate-400 text-xs font-bold">{subLabel}</span>}
        {isLive && (
          <span className="flex items-center gap-1.5 text-secondary text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span> LIVE
          </span>
        )}
      </div>
      <div>
        <p className="text-slate-500 text-sm font-semibold mb-1">{label}</p>
        <p className="text-4xl font-extrabold font-headline tracking-tight">{value}</p>
      </div>
    </motion.div>
  );
}

function AIEngineStat({ label, value, status, animate, spin }: any) {
  return (
    <div className="bg-white/5 p-3.5 rounded-2xl border border-white/10">
      <p className="text-[9px] text-slate-400 uppercase font-black mb-1">{label}</p>
      <div className="flex justify-between items-center">
        <span className="text-sm font-bold">{value}</span>
        <div className={`w-1.5 h-1.5 rounded-full bg-${status} ${animate ? 'animate-pulse' : ''} ${spin ? 'animate-spin' : ''}`}></div>
      </div>
    </div>
  );
}

function ConditionProgress({ label, value, progress }: any) {
  return (
    <div>
      <div className="flex justify-between items-end mb-2">
        <span className="text-sm font-bold">{label}</span>
        <span className="text-sm font-black text-primary">{value}</span>
      </div>
      <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="h-full bg-primary rounded-full shadow-[0_0_10px_rgba(0,122,255,0.4)]"
        ></motion.div>
      </div>
    </div>
  );
}

function RiskLegend({ color, label }: any) {
  return (
    <div className="flex items-center gap-2">
      <span className={`w-2 h-2 rounded-full bg-${color}`}></span>
      <span className="text-[10px] font-bold text-slate-500 uppercase">{label}</span>
    </div>
  );
}

function AgeBar({ label, height, active }: any) {
  return (
    <div className="flex-1 flex flex-col items-center gap-3 group">
      <motion.div 
        initial={{ height: 0 }}
        animate={{ height }}
        className={`w-full rounded-xl ${active ? 'bg-primary shadow-[0_0_15px_rgba(0,122,255,0.3)]' : 'bg-slate-100 group-hover:bg-primary/20'} transition-all`}
      ></motion.div>
      <span className={`text-[10px] font-bold ${active ? 'text-primary' : 'text-slate-400'}`}>{label}</span>
    </div>
  );
}

function RegionCard({ name, status, patients, coverage, alert, color }: any) {
  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      className={`glass-card p-5 rounded-3xl border-l-4 border-l-${color}`}
    >
      <div className="flex justify-between items-start mb-4">
        <span className="text-sm font-extrabold">{name}</span>
        <span className={`text-[8px] bg-${color}/10 text-${color} px-1.5 py-0.5 rounded font-black`}>{status}</span>
      </div>
      <div className="space-y-2 text-[10px] font-bold text-slate-500">
        <div className="flex justify-between"><span>Patients</span> <span className="text-on-surface">{patients}</span></div>
        <div className="flex justify-between"><span>Coverage</span> <span className="text-on-surface">{coverage}</span></div>
        {alert && <div className={`mt-2 py-1.5 px-2 bg-${color}/5 rounded text-${color} text-[9px]`}>{alert}</div>}
      </div>
    </motion.div>
  );
}

function TableRow({ rank, name, region, beds, adoption, mortality, score, status, statusColor }: any) {
  return (
    <tr className="hover:bg-primary/5 transition-all cursor-pointer group">
      <td className="px-8 py-5">
        <span className={`w-7 h-7 ${rank === '01' ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-400'} rounded-full flex items-center justify-center font-black text-xs`}>
          {rank}
        </span>
      </td>
      <td className="px-8 py-5 font-bold">{name}</td>
      <td className="px-8 py-5 text-slate-500">{region}</td>
      <td className="px-8 py-5">{beds}</td>
      <td className="px-8 py-5">
        <div className="flex items-center gap-2">
          {adoption}
          <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
            <div className={`h-full bg-${statusColor} w-[${adoption}]`}></div>
          </div>
        </div>
      </td>
      <td className={`px-8 py-5 text-${statusColor}`}>{mortality}</td>
      <td className="px-8 py-5">
        <span className="px-3 py-1 bg-primary text-white text-[10px] font-black rounded-full">{score}</span>
      </td>
      <td className="px-8 py-5">
        <span className={`px-3 py-1 bg-${statusColor}/10 text-${statusColor} text-[10px] font-black rounded-full uppercase`}>
          {status}
        </span>
      </td>
    </tr>
  );
}

function ImpactStat({ label, value, trend, sub, isCheck }: any) {
  return (
    <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-black/5">
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{label}</p>
      <p className="text-5xl font-black text-primary mb-1">{value}</p>
      {trend && (
        <p className="text-xs font-bold text-secondary flex items-center gap-1">
          <span className="material-symbols-outlined text-sm">{isCheck ? 'check_circle' : 'trending_up'}</span> {trend}
        </p>
      )}
      {sub && <p className="text-xs font-bold text-slate-500">{sub}</p>}
    </div>
  );
}

function SecurityItem({ icon, label, value }: any) {
  return (
    <div className="flex justify-between items-center px-4 py-3 bg-white rounded-xl shadow-sm border border-black/5">
      <div className="flex items-center gap-3">
        <span className="material-symbols-outlined text-slate-400 text-sm">{icon}</span>
        <span className="text-xs font-bold">{label}</span>
      </div>
      <span className="text-xs font-black text-secondary">{value}</span>
    </div>
  );
}

function PolicyItem({ title, desc }: any) {
  return (
    <div className="p-5 bg-tertiary/5 border border-tertiary/10 rounded-2xl flex gap-4">
      <div className="text-tertiary mt-1"><span className="material-symbols-outlined text-lg">info</span></div>
      <div>
        <p className="text-xs font-bold mb-1">{title}</p>
        <p className="text-[10px] text-slate-500">{desc}</p>
      </div>
    </div>
  );
}

function NavButton({ icon, label }: any) {
  return (
    <button className="flex flex-col items-center gap-1 px-4 group">
      <span className="material-symbols-outlined text-slate-400 group-hover:text-primary transition-all">{icon}</span>
      <span className="text-[9px] font-black uppercase tracking-widest text-slate-400 group-hover:text-primary transition-all">{label}</span>
    </button>
  );
}
